<?php
/**
*Plugin Name: Assessment Task
*Description: Create a Plugin given from GublooTech as a Assessment Task
*Version: 1.0.0
*Author: Muhammad Farhan
*License: GPL2
*Text Domain: assessment-task
*Plugin Prefix : at_
*/
//Plugin Prefix is used for making names of functions unique

add_action('init', 'at_create_custom_posttypes'); //Create Custom Post Type of name "Doctors" and post type "at_doctors"

function at_create_custom_posttypes() {

    $doctor_defination_array = array (
        'name' => __('Doctors', 'Post Type General Name', 'assessment-task'),
        'singular_name' => __('Doctors', 'Post Type Singular Name', 'assessment-task'),
        'menu_name' => __('Doctors', 'assessment-task'),
        'name_admin_bar' => __('Admin Name', 'assessment-task'),
        'archives' => __('Archives', 'assessment-task'),
        'all_items' => __('All Doctors', 'assessment-task')
    );
    register_post_type('at_doctors', array (  //register custom post named as "Doctors" with type "at_doctors"
        'label' => __('Custom Post','assessment-task'),
        'description' => __('This is Testing Plugin','assessment-task'),
        'labels' => $doctor_defination_array,
        'menu_icon' => 'dashicons-admin-users',
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_admin_bar'   => true,
        'show_in_nav_menus'   => false,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'show_in_rest'        => true
    ));
}


add_action('rest_api_init', function() { //Create a json api which is accessed in function.php to display doctors with the help of shortcode on front
    register_rest_route('at', 'doctors', [
        'methods' => 'GET',
        'callback' => 'at_all_doctors',
    ]);
    //apiurl : yoursiteurl/wp-json/at/doctors
});

function at_all_doctors() {
    global $wpdb;
    $argumented_array_for_doctors = array(
        'post_type' => 'at_doctors',
        'numberposts' => -1,
        'post_status' => 'Publish',
    );
    $getting_doctors = get_posts($argumented_array_for_doctors);
    $data = [];
    $i = 0;
    foreach($getting_doctors as $doctor) {
        $permalink = get_permalink($doctor->ID);
        $data[$i]['id'] = $doctor->ID;
        $data[$i]['title'] = $doctor->post_title;
        $data[$i]['link'] = $permalink;
        $i++;
    }
    return $data;
}
